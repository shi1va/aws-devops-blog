"""
TaskFlow API v2 — AWS DevOps Practice Project
Full CI/CD: CodeArtifact → CodeBuild → CodePipeline → CodeDeploy → EKS + ArgoCD
"""

from flask import Flask, jsonify, request
from datetime import datetime
import uuid, os

app = Flask(__name__)

# ── Runtime info (injected by CodeBuild / EKS env vars) ─────────────────────
BUILD_NUMBER = os.getenv("BUILD_NUMBER", "local")
IMAGE_TAG    = os.getenv("IMAGE_TAG",    "dev")
ENV          = os.getenv("ENV",          "development")
REGION       = os.getenv("AWS_REGION",  "ap-south-1")

TASKS = {}

# ── Health / Info ────────────────────────────────────────────────────────────

@app.route("/", methods=["GET"])
def root():
    return jsonify({"service": "taskflow-api", "status": "running", "env": ENV})

@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status":       "ok",
        "version":      "2.0.0",
        "build_number": BUILD_NUMBER,
        "image_tag":    IMAGE_TAG,
        "env":          ENV,
        "region":       REGION,
        "timestamp":    datetime.utcnow().isoformat(),
    })

@app.route("/ready", methods=["GET"])
def ready():
    """Kubernetes readiness probe."""
    return jsonify({"ready": True}), 200

@app.route("/live", methods=["GET"])
def live():
    """Kubernetes liveness probe."""
    return jsonify({"alive": True}), 200

# ── Tasks CRUD ───────────────────────────────────────────────────────────────

@app.route("/tasks", methods=["GET"])
def get_tasks():
    status = request.args.get("status")
    tasks  = list(TASKS.values())
    if status:
        tasks = [t for t in tasks if t["status"] == status]
    return jsonify({"tasks": tasks, "count": len(tasks)})

@app.route("/tasks/<task_id>", methods=["GET"])
def get_task(task_id):
    task = TASKS.get(task_id)
    if not task:
        return jsonify({"error": f"Task '{task_id}' not found"}), 404
    return jsonify(task)

@app.route("/tasks", methods=["POST"])
def create_task():
    data = request.get_json()
    if not data or not data.get("title"):
        return jsonify({"error": "title is required"}), 400
    task_id = str(uuid.uuid4())[:8]
    task = {
        "id":          task_id,
        "title":       data["title"],
        "description": data.get("description", ""),
        "status":      "todo",
        "priority":    data.get("priority", "medium"),
        "created_at":  datetime.utcnow().isoformat(),
        "updated_at":  datetime.utcnow().isoformat(),
    }
    TASKS[task_id] = task
    return jsonify(task), 201

@app.route("/tasks/<task_id>", methods=["PUT"])
def update_task(task_id):
    task = TASKS.get(task_id)
    if not task:
        return jsonify({"error": f"Task '{task_id}' not found"}), 404
    data = request.get_json()
    for field in {"title", "description", "status", "priority"}:
        if field in data:
            task[field] = data[field]
    task["updated_at"] = datetime.utcnow().isoformat()
    return jsonify(task)

@app.route("/tasks/<task_id>", methods=["DELETE"])
def delete_task(task_id):
    if TASKS.pop(task_id, None) is None:
        return jsonify({"error": f"Task '{task_id}' not found"}), 404
    return jsonify({"deleted": task_id}), 200

@app.route("/stats", methods=["GET"])
def stats():
    all_tasks = list(TASKS.values())
    return jsonify({
        "total": len(all_tasks),
        "by_status": {
            s: sum(1 for t in all_tasks if t["status"] == s)
            for s in ("todo", "in_progress", "done")
        },
        "by_priority": {
            p: sum(1 for t in all_tasks if t["priority"] == p)
            for p in ("low", "medium", "high")
        },
    })

if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=(ENV == "development"))
