"""Tests for TaskFlow API v2."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
from app.app import app, TASKS

@pytest.fixture
def client():
    app.config["TESTING"] = True
    TASKS.clear()
    with app.test_client() as c:
        yield c
    TASKS.clear()

def test_root(client):
    r = client.get("/")
    assert r.status_code == 200

def test_health(client):
    r = client.get("/health")
    assert r.status_code == 200
    assert r.get_json()["status"] == "ok"

def test_readiness(client):
    assert client.get("/ready").status_code == 200

def test_liveness(client):
    assert client.get("/live").status_code == 200

def test_create_task(client):
    r = client.post("/tasks", json={"title": "Deploy to EKS"})
    assert r.status_code == 201
    assert r.get_json()["title"] == "Deploy to EKS"

def test_create_task_no_title(client):
    assert client.post("/tasks", json={}).status_code == 400

def test_get_tasks_empty(client):
    r = client.get("/tasks")
    assert r.get_json()["count"] == 0

def test_get_task_not_found(client):
    assert client.get("/tasks/notexist").status_code == 404

def test_update_task(client):
    tid = client.post("/tasks", json={"title": "T"}).get_json()["id"]
    r = client.put(f"/tasks/{tid}", json={"status": "done"})
    assert r.get_json()["status"] == "done"

def test_delete_task(client):
    tid = client.post("/tasks", json={"title": "Del"}).get_json()["id"]
    assert client.delete(f"/tasks/{tid}").status_code == 200
    assert client.get(f"/tasks/{tid}").status_code == 404

def test_stats(client):
    client.post("/tasks", json={"title": "A", "priority": "high"})
    client.post("/tasks", json={"title": "B"})
    data = client.get("/stats").get_json()
    assert data["total"] == 2
    assert data["by_priority"]["high"] == 1
