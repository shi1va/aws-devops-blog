#!/bin/bash
# CodeDeploy lifecycle hook — AfterAllowTraffic
# Runs after traffic is fully routed to the new version.
set -e

echo "=== AfterAllowTraffic hook: $(date) ==="
echo "Deployment successful! Traffic is now flowing to the new revision."

# Optional: send a notification, update a CMDB, tag the deployment, etc.
# aws sns publish --topic-arn $SNS_TOPIC_ARN --message "taskflow-api deployed successfully"

echo "=== AfterAllowTraffic complete ==="
