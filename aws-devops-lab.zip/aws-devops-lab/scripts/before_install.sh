#!/bin/bash
# CodeDeploy lifecycle hook — BeforeInstall
# Runs before the new revision is deployed.
set -e

echo "=== BeforeInstall hook: $(date) ==="

# Verify kubectl is available on the CodeDeploy agent
which kubectl || { echo "ERROR: kubectl not found"; exit 1; }

# Verify we can reach the EKS cluster
kubectl cluster-info --request-timeout=10s || {
  echo "ERROR: Cannot reach EKS cluster"
  exit 1
}

echo "=== BeforeInstall complete ==="
