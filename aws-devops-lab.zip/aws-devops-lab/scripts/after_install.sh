#!/bin/bash
# CodeDeploy lifecycle hook — AfterInstall
# Runs after the new revision files are copied to the instance.
set -e

echo "=== AfterInstall hook: $(date) ==="

# Apply namespace first (idempotent)
kubectl apply -f k8s/namespace.yaml

# Apply ConfigMap and Secrets before deployment
kubectl apply -f k8s/configmap.yaml

# Apply the deployment (image tag already updated by CodeBuild)
kubectl apply -f k8s/deployment.yaml

# Apply the service
kubectl apply -f k8s/service.yaml

echo "=== AfterInstall complete ==="
