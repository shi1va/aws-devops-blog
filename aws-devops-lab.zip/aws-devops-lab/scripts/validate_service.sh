#!/bin/bash
# CodeDeploy lifecycle hook — BeforeAllowTraffic / Validate
# Waits for rollout and hits the health endpoint.
set -e

NAMESPACE="taskflow"
DEPLOY="taskflow-api"
TIMEOUT="120s"

echo "=== ValidateService hook: $(date) ==="

# Wait for rollout to complete
echo "Waiting for deployment rollout (timeout: $TIMEOUT)..."
kubectl rollout status -n $NAMESPACE deployment/$DEPLOY --timeout=$TIMEOUT || {
  echo "ERROR: Rollout timed out or failed — triggering rollback"
  kubectl rollout undo -n $NAMESPACE deployment/$DEPLOY || true
  exit 1
}

# Get a pod name for health check
POD=$(kubectl get pods -n $NAMESPACE -l app=$DEPLOY \
  --field-selector=status.phase=Running \
  -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)

if [ -z "$POD" ]; then
  echo "ERROR: No running pods found"
  exit 1
fi

echo "Checking /health on pod $POD..."
kubectl exec -n $NAMESPACE $POD -- \
  wget -q -O- http://localhost:5000/health | grep '"status": "ok"' || {
  echo "ERROR: Health check failed"
  exit 1
}

echo "=== ValidateService passed ==="
